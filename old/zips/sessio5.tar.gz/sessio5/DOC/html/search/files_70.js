var searchData=
[
  ['palabra_2ehpp',['Palabra.hpp',['../_palabra_8hpp.html',1,'']]],
  ['pro2_5fs52_2ecpp',['pro2_s52.cpp',['../pro2__s52_8cpp.html',1,'']]]
];
