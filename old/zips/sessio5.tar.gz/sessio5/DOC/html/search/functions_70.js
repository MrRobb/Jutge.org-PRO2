var searchData=
[
  ['palabra',['Palabra',['../class_palabra.html#a8e74f02e148cdcb5bb91bc2ae193183e',1,'Palabra']]]
];
