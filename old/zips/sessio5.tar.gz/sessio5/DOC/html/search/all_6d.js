var searchData=
[
  ['main',['main',['../pro2__s52_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'pro2_s52.cpp']]],
  ['max_5ffrec',['max_frec',['../class_lista_palabras.html#aaafa09ef438a8ee956d2c1a095e578f4',1,'ListaPalabras']]]
];
