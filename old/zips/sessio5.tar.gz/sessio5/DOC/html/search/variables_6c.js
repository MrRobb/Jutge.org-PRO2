var searchData=
[
  ['letras',['letras',['../class_palabra.html#a30488f9b1c9e50c491311561054cbd5b',1,'Palabra']]],
  ['longitud',['longitud',['../class_palabra.html#a8dd8ad3a263749e9ec5c50d66fad024a',1,'Palabra']]]
];
