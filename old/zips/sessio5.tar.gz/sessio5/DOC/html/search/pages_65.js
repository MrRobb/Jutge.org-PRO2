var searchData=
[
  ['ejemplo_20de_20dise_c3_b1o_20modular_3a_20_20factor_20psi_2e',['Ejemplo de diseño modular:  Factor Psi.',['../index.html',1,'']]]
];
