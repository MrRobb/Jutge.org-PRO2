var searchData=
[
  ['leer',['leer',['../class_celula.html#a5124ea0c0da24dfc295dcc428652ee43',1,'Celula::leer()'],['../class_organismo.html#a189d611401e25f603103c420d0b62e23',1,'Organismo::leer()'],['../class_sistema.html#ae670549104642dd4664ac8f794b4b1e9',1,'Sistema::leer()']]],
  ['leer_5farbol_5fcelulas',['leer_arbol_celulas',['../class_organismo.html#abf016c166b00ca0f7016afd44d282913',1,'Organismo']]],
  ['lucha_5farboles',['lucha_arboles',['../class_organismo.html#aaf643a47840f855ed3e105970f75a078',1,'Organismo']]],
  ['lucha_5fcelulas',['lucha_celulas',['../class_celula.html#a3dd8be98f1548b02696e2fc32b8d19b4',1,'Celula']]],
  ['lucha_5forganismos',['lucha_organismos',['../class_organismo.html#a2f4573f69288fa8ec05ec709f2336a8d',1,'Organismo']]],
  ['luchas_5forg_5fcola',['luchas_org_cola',['../class_sistema.html#a9123a18225eece5cf29d0d59067ac509',1,'Sistema']]]
];
