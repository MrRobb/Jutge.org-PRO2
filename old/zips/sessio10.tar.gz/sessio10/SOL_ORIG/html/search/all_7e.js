var searchData=
[
  ['_7ecelula',['~Celula',['../class_celula.html#aa102b024e4c8d91a2f69afa14d4e4130',1,'Celula']]],
  ['_7eorganismo',['~Organismo',['../class_organismo.html#ad1ba743e609a358f1479ebf341220747',1,'Organismo']]],
  ['_7esistema',['~Sistema',['../class_sistema.html#aafc86e0f2c3d734fb4c0985f70c27a1a',1,'Sistema']]]
];
