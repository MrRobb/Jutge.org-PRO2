var searchData=
[
  ['incrementar_5fvictimas',['incrementar_victimas',['../class_organismo.html#ae498385e40b42c4e9b11226befd6e4c6',1,'Organismo']]]
];
