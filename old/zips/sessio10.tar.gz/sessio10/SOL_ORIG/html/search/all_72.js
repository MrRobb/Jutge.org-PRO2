var searchData=
[
  ['recolocar',['recolocar',['../class_sistema.html#a251ac725ddac0022e4845faec14004ef',1,'Sistema']]]
];
