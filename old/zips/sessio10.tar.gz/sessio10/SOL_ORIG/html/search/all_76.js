var searchData=
[
  ['victimas',['victimas',['../class_organismo.html#abb3e56487a080df544a6ff96e5e42520',1,'Organismo']]]
];
