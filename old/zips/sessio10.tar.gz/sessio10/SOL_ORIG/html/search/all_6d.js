var searchData=
[
  ['main',['main',['../pro2_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'pro2.cpp']]],
  ['mal',['mal',['../class_sistema.html#a11fa1af3dde26025dd10b3ac103f426e',1,'Sistema']]],
  ['maligno',['maligno',['../class_organismo.html#a85a5d1b9d31fa209d1ed0d596dbbed61',1,'Organismo']]]
];
