var searchData=
[
  ['num_5fvictimas',['num_victimas',['../class_organismo.html#aadcc0750f9405e7334ac6a69e4ebb1b8',1,'Organismo']]]
];
