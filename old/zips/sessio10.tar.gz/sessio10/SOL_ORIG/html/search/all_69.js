var searchData=
[
  ['i_5ftol',['i_tol',['../class_celula.html#abda46be7b30a13909d9819c46238080b',1,'Celula']]],
  ['id',['id',['../class_celula.html#a0984a8b3deeed4979ed6f6141edc3c0c',1,'Celula::id()'],['../class_organismo.html#a30be1823d3711fec651a5a4b1dc1cee5',1,'Organismo::id()'],['../class_sistema.html#a69ba5e2cce55afc2a47d899a1100a42a',1,'Sistema::id()']]],
  ['id_5fvacia',['ID_VACIA',['../class_celula.html#affff67b41ead0b1f3a3f4faad6c049ac',1,'Celula']]],
  ['incrementar_5fvictimas',['incrementar_victimas',['../class_organismo.html#ae498385e40b42c4e9b11226befd6e4c6',1,'Organismo']]]
];
