var searchData=
[
  ['anadir_5fid',['anadir_id',['../class_organismo.html#a4fa50ea637c25ee2b04bd1805ec634dc',1,'Organismo']]],
  ['anadir_5forganismo',['anadir_organismo',['../class_sistema.html#a6522b718fc0701d38c2e2d2c2d2e88a6',1,'Sistema']]]
];
