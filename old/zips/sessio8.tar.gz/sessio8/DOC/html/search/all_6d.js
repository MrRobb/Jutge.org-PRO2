var searchData=
[
  ['main',['main',['../pro2__s8_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'pro2_s8.cc']]],
  ['modificar_5fprenda',['modificar_prenda',['../class_prenda.html#a598bccf93cb8aa217a8533c0307c686f',1,'Prenda']]]
];
