var searchData=
[
  ['prenda',['Prenda',['../class_prenda.html#adfd86b131c7f40c58b0cb4200eb55129',1,'Prenda::Prenda()'],['../class_prenda.html#af15ff723083040b89bc495b4ec4b914e',1,'Prenda::Prenda(int pes, bool col)']]]
];
