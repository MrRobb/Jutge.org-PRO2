#include "listIOint.hpp"


bool pert_llista_int(const list<int>& l, int x)
/* Pre: cert */
/* Post: El resultat indica si x hi �s o no a l */
{
  bool b = false;
  list<int>::const_iterator it= l.begin();
  while ( it != l.end() and not b){
    if (*it == x) b= true;
    else ++it;
  }
  return b;
}

int main(){

  list<int> l;
  cout << "Entra llista enters (acabada per 0): " << endl;
  llegir_llista_int(l,0);

  cout << "N�mero a cercar: "; 
  int x = readint();
  bool b = pert_llista_int(l,x);
  if (b) cout << "Hi �s" << endl;
  else cout << "No hi �s" << endl;
  cout << "Escrivim la llista per veure que no s'ha modificat: " << endl;
  escriure_llista_int(l);

}
