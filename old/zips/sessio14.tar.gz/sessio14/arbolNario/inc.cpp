#include "ArbNIOint.hpp"

int main (){
  cout << "Pon la aridad:" << endl;
  ArbreNari<int> a(readint());
  cout << "Pon el arbol en preorden:" << endl;

  llegir_arbre_int(a,0);

  ArbreNari<int> b(a);
  cout << "b en preorden:" << endl;
  escriure_arbre_int(b);
  cout << endl;
  cout << "escribe la k:" << endl;
  int k = readint();
  b.inc_arbreNari(k);
  cout << "a en preorden:" << endl;
  escriure_arbre_int(a);
  cout << endl;
  cout << "b en preorden:" << endl;
  escriure_arbre_int(b);
  cout << endl;
  ArbreNari<int> c(100,3);
  cout << "c en preorden:" << endl;
  escriure_arbre_int(c);
  cout << endl;
 }
