#include "utils.PRO2"

int  main ()
{
  cout << "Entra dos nombres enters: ";
  int x=readint();
  int y= readint();
  int sum = x+y;
  cout << "La suma de " << x << " i " << y << " es " << sum <<endl;
}

